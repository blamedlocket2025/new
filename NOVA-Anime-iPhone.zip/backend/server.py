from flask import Flask, jsonify, send_from_directory
from pathlib import Path

app=Flask(__name__, static_folder="../frontend")
CATALOG=[
 {"id":1,"title":"Neon Horizon","genres":["Action","Sci-Fi"]},
 {"id":2,"title":"Moonblade","genres":["Fantasy","Adventure"]},
 {"id":3,"title":"Cyber Spirit","genres":["Action","Cyberpunk"]},
 {"id":4,"title":"Skybound","genres":["Adventure","Drama"]}
]
@app.get("/api/anime")
def anime(): return jsonify(CATALOG)
@app.get("/")
def index(): return send_from_directory("../frontend","index.html")
if __name__=="__main__": app.run(host="0.0.0.0",port=5000,debug=True)
