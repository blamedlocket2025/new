# NOVA Anime — iPhone PWA

A futuristic iPhone-first anime catalogue/streaming UI.

## Run locally
1. Install Python 3.
2. `cd backend`
3. `pip install -r requirements.txt`
4. `python server.py`
5. Open the shown local address in Safari.

## Install on iPhone
Host the project over HTTPS, open the site in Safari, tap Share → Add to Home Screen.

## Streaming and downloads
The included UI intentionally uses placeholder catalogue/video data. Connect an authorized anime catalogue and streaming provider in `backend/server.py` and `frontend/app.js`. Actual downloads should only be enabled for content for which your service/provider grants offline-download rights.

## Production
For App Store distribution, wrap the web app with a native iOS shell (for example a Swift/WebKit project) and comply with Apple's App Store rules and the rights/licensing requirements of every video source.
