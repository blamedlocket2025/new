const demo=[
 {id:1,title:"Neon Horizon",genre:"Action • Sci-Fi",desc:"A mysterious signal awakens a new generation of pilots.",rating:"8.9"},
 {id:2,title:"Moonblade",genre:"Fantasy • Adventure",desc:"A young warrior discovers a blade that remembers every battle.",rating:"8.7"},
 {id:3,title:"Cyber Spirit",genre:"Action • Cyberpunk",desc:"A city where memories can be traded and stolen.",rating:"9.1"},
 {id:4,title:"Skybound",genre:"Adventure • Drama",desc:"Friends chase a legendary island above the clouds.",rating:"8.5"}
];
let library=JSON.parse(localStorage.getItem("novaLibrary")||"[]");
let downloads=JSON.parse(localStorage.getItem("novaDownloads")||"[]");
const screen=document.querySelector("#screen"), modal=document.querySelector("#modal");

function save(){localStorage.setItem("novaLibrary",JSON.stringify(library));localStorage.setItem("novaDownloads",JSON.stringify(downloads))}
function poster(a){return `<div class="poster"><span>${a.title}</span></div>`}
function card(a){return `<article class="card" onclick="details(${a.id})">${poster(a)}<p>${a.title}</p><p class="meta">★ ${a.rating} · ${a.genre.split(" • ")[0]}</p></article>`}
function home(){screen.innerHTML=`<div class="content">
<section class="hero"><div><span class="eyebrow">Featured anime</span><h1>Neon<br>Horizon</h1><p>${demo[0].desc}</p><div class="buttons"><button class="btn primary" onclick="details(1)">▶ Watch</button><button class="btn ghost" onclick="toggleList(1)">＋ My List</button></div></div></section>
<section class="section"><div class="sectionhead"><h2>Trending now</h2><span>View all</span></div><div class="cards">${demo.map(card).join("")}</div></section>
<section class="section"><div class="sectionhead"><h2>Explore</h2><span>Genres</span></div><div class="cards">${demo.slice().reverse().map(card).join("")}</div></section>
</div>`}
function search(){screen.innerHTML=`<div class="content"><h1>Search</h1><input class="search" id="q" placeholder="Search anime..." oninput="doSearch(this.value)"><div id="results"></div></div>`}
function doSearch(q){let r=demo.filter(a=>a.title.toLowerCase().includes(q.toLowerCase())||a.genre.toLowerCase().includes(q.toLowerCase()));document.querySelector("#results").innerHTML=r.length?r.map(a=>`<div class="result" onclick="details(${a.id})"><div class="mini"></div><div><b>${a.title}</b><p class="meta">${a.genre} · ★ ${a.rating}</p></div></div>`).join(""):`<div class="empty">No anime found.</div>`}
function libraryPage(){screen.innerHTML=`<div class="content"><h1>My List</h1>${library.length?`<div class="cards">${library.map(id=>card(demo.find(a=>a.id===id))).join("")}</div>`:`<div class="empty">Your list is empty.<br>Add anime to see it here.</div>`}</div>`}
function downloadsPage(){screen.innerHTML=`<div class="content"><h1>Downloads</h1>${downloads.length?downloads.map(id=>`<div class="result"><div class="mini"></div><div><b>${demo.find(a=>a.id===id).title}</b><p class="meta">Available offline · Licensed source required</p></div></div>`).join(""):`<div class="empty">No offline episodes yet.<br>Downloads will appear here when a connected provider permits offline playback.</div>`}</div>`}
function details(id){let a=demo.find(x=>x.id===id);modal.classList.remove("hidden");modal.innerHTML=`<div class="sheet"><button class="close" onclick="modal.classList.add('hidden')">Close</button><div class="poster" style="height:260px;border-radius:20px">${a.title}</div><h1>${a.title}</h1><p class="meta">★ ${a.rating} · ${a.genre}</p><p>${a.desc}</p><div class="buttons"><button class="btn primary" onclick="watch(${id})">▶ Watch</button><button class="btn ghost" onclick="toggleList(${id})">♡ My List</button><button class="btn ghost" onclick="download(${id})">⇩ Download</button></div><h2>Episodes</h2>${[1,2,3,4,5].map(n=>`<div class="result"><div><b>Episode ${n}</b><p class="meta">24 min · HD</p></div><button class="btn ghost" onclick="watch(${id},${n})">Play</button></div>`).join("")}</div>`}
function toggleList(id){library=library.includes(id)?library.filter(x=>x!==id):[...library,id];save();alert(library.includes(id)?"Added to My List":"Removed from My List")}
function download(id){if(!downloads.includes(id)){downloads.push(id);save();alert("Added to Downloads. Connect a licensed provider to enable actual offline video storage.")}}
function watch(id,ep=1){modal.innerHTML=`<div class="sheet"><button class="close" onclick="modal.classList.add('hidden')">Close</button><h2>${demo.find(a=>a.id===id).title} — Episode ${ep}</h2><div style="aspect-ratio:16/9;background:#000;border-radius:18px;display:grid;place-items:center;color:#777">Licensed video player<br><small>Connect your authorized streaming provider here.</small></div><p class="meta">Playback UI ready for HLS/MP4 provider integration.</p></div>`}
function page(p){document.querySelectorAll(".navitem").forEach(x=>x.classList.toggle("active",x.dataset.page===p));({home,search,library:libraryPage,downloads:downloadsPage}[p]||home)()}
document.querySelectorAll(".navitem").forEach(x=>x.onclick=()=>page(x.dataset.page));
document.querySelector("#profileBtn").onclick=()=>alert("Profile / account settings can be connected to your backend.");
home();
if("serviceWorker" in navigator) navigator.serviceWorker.register("../service-worker.js");